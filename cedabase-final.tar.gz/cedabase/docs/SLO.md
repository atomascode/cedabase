# Service Level Objectives (SLOs)

Cedabase aims to provide a robust and compliant data platform for EU
organisations.  This document defines the availability and performance
objectives for the MVP and outlines the corresponding monitoring and alerting
rules.

## Availability

| Service        | Objective              | Rationale                          |
|---------------|------------------------|------------------------------------|
| API Gateway   | 99.9% uptime per month | Users must be able to access data  |
| Database      | 99.95% uptime per month| Data loss or downtime is critical  |
| Studio        | 99.5% uptime per month | Admin UI can have brief outages    |

These targets translate to the following maximum downtime per month:

* 99.9%: 43m 12s
* 99.95%: 21m 36s
* 99.5%: 3h 36m

## Performance

| Metric                         | Objective             | Notes                     |
|-------------------------------|-----------------------|---------------------------|
| p95 REST latency              | < 250 ms              | for simple CRUD requests  |
| Realtime fan‑out latency      | < 500 ms              | from write to broadcast   |
| Storage upload throughput     | > 10 MB/s per client  | measured via k6          |

## Monitoring & Alerting

* Prometheus scrapes Traefik, Postgres and node exporters.
* Alertmanager rules:
  * **High HTTP error rate** – fire when 5xx responses exceed 1% of total for
    5 minutes.
  * **Slow REST API** – fire when p95 latency > 250 ms for 10 minutes.
  * **High CPU/IO** – fire when CPU or disk utilisation exceeds 80% for
    15 minutes.
  * **Database replication lag** – (future) warn when WAL lag > 5 seconds.
  * **Backup failure** – alert if last backup timestamp > 36 hours.
* Alerts integrate with the on‑call channel and create incident tickets.

## Data Retention & Logging

* Application logs are retained for 14 days.
* Audit logs (API key rotations, project changes) are retained for 90 days.
* Metrics are retained for 30 days.

## Security Considerations

* All cookies are set with `HttpOnly` and `Secure` flags.
* JWTs have a short expiry (1 h) and must be refreshed using a rotation token.
* CORS is restricted to configured origins; CSRF tokens are enforced on
  state‑changing requests.
* The database port is never exposed publicly.  Firewalls restrict access.

These SLOs will be reviewed quarterly and adjusted as Cedabase scales.