# Week 3 – Hetzner Infrastructure via Terraform

Date: 2025‑09‑20

## Context

The third week of the Cedabase project focuses on provisioning a production
environment on Hetzner Cloud.  The goal is to codify the baseline
infrastructure using Terraform so that we can reproduce our network, servers,
load balancer, volumes and security groups reliably.  This week introduces
cloud‑init scripts for base node hardening and sets the stage for continuous
deployment later on.

Important references include PostgREST requirements for secure database
connectivity【555061165238131†L146-L157】 and the Realtime server configuration
options for secure channels【524236409301486†L79-L154】.  These inform our
private networking and firewall rules to ensure the database is never exposed
publicly and that only the load balancer has public ingress.

## Decision

1. **Terraform provider** – We chose the official `hetznercloud/hcloud`
   provider to manage all infrastructure.  It supports VPC creation, firewalls,
   servers, volumes and load balancers.  The configuration lives under
   `infra/terraform` with a single `main.tf` for readability.
2. **Networking** – We provision a private network (`hcloud_network`) with a
   configurable CIDR and add a subnet in the `eu-central` zone.  Servers join
   this network so that the database remains private.  A firewall opens only
   ports 80/443 and optionally 22 for SSH when enabled.
3. **Servers** – Two CPX app nodes (count configurable) and one CCX database
   node are created.  The database attaches a dedicated volume for persistent
   storage.  Cloud‑init YAML files configure each node: installing Docker,
   enabling UFW, disabling password authentication and configuring basic
   hardening.
4. **Load balancer** – A Hetzner load balancer fronts the app nodes with
   TCP listeners on 80 and 443.  Traefik will later terminate TLS and route
   paths to the various services.  The load balancer attaches to the same
   private network and will receive a floating IP in later weeks.
5. **Variables and outputs** – Inputs like token, server sizes, SSH keys and
   enable‑SSH flag are defined in `variables.tf`.  Outputs surface the
   load balancer’s public IP and the database’s private IP for downstream
   configuration.

## Consequences

By codifying our Hetzner environment in Terraform we can repeatedly create and
tear down stacks for testing.  The cloud‑init scripts ensure each server is
secure by default and ready to run Docker Compose.  In Week 4 we will deploy
our services onto these nodes via Docker Compose and validate the end‑to‑end
MVP.