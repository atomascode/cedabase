# Week 8 – Beta Launch, GDPR & Documentation

Date: 2025‑10‑25

## Context

The final week culminates in the beta launch of Cedabase.  We needed to
finalise legal and operational documentation, implement data subject request
flows, rehearse disaster recovery and prepare public pricing.  Launching a
compliant EU‑first service requires careful attention to GDPR and clear
communication with users.

## Decision

1. **GDPR documentation** – We added a comprehensive GDPR document
   (`docs/GDPR.md`) covering our Data Processing Agreement (DPA) template,
   Records of Processing, data subject request procedures and retention
   policies.  The document explains how to invoke export and delete
   endpoints for individual users and how to contact the DPO.
2. **Data subject request endpoints** – Two stored procedures and PostgREST
   endpoints were designed (`/admin/dsr/export` and `/admin/dsr/delete`).
   These require a service JWT and return either a JSON export or confirmation
   of deletion.  Audit events are recorded for each invocation.
3. **Retention and deletion** – Policies were formalised: authentication
   records retained for one year after account deletion, audit logs for
   90 days, application data until a customer deletes their project plus a
   30‑day grace period.  Backup schedules continue to run nightly and weekly.
4. **Pricing page** – The Studio now includes a pricing page outlining
   indicative tiers for GA.  The beta remains free for early adopters.  The
   page stresses that pricing is subject to change and invites enquiries for
   enterprise plans.
5. **Disaster recovery drill** – We executed a manual backup/restore drill
   using the scripts from Week 4.  The drill confirmed that nightly dumps can
   be restored onto a fresh database node and that the application can be
   re‑pointed by updating the database URL.  Runbook documentation was
   updated accordingly.

## Consequences

The platform is now ready for external users.  We have documented privacy
obligations, implemented export/delete flows and rehearsed recovery.  Pricing
information sets expectations and will help onboard early adopters.  Future
development will focus on polish, scaling and user feedback as we move
towards General Availability.