# Week 5 – Tenancy, Billing Stub & Admin

Date: 2025‑10‑04

## Context

With the core stack running in production, the fifth week introduces
multi‑tenant capabilities, API key management and a placeholder for billing.
Cedabase needs to support multiple organisations, each with one or more
projects, and to issue separate anonymous and service API keys per project.
Rate limiting and audit logging are also important features to prevent abuse.

In PostgREST the anonymous role is used for unauthenticated clients
【555061165238131†L146-L157】 and row‑level security policies restrict data access.  We leverage
these features by associating each JWT with an `org_id` claim.  Realtime
continues to enforce the `authenticated` role for websocket channels【524236409301486†L79-L154】.

## Decision

1. **Database schema** – We created `organisations`, `projects` and `api_keys`
   tables in a new migration.  Each project belongs to an organisation and
   can have multiple API keys with roles `anon` and `service`.  Row Level
   Security is enabled on these tables, and policies reference a JWT claim
   `org_id` for access control.
2. **Seed data** – A new seed script populates a development organisation and
   project along with generated anon and service keys.  In production these
   keys will be generated via a rotation endpoint.
3. **API key rotation stub** – The Studio application exposes a settings page
   where users can view and rotate their keys.  Rotation is simulated by
   generating a random string in the frontend.  In future weeks this will
   call a backend endpoint that inserts a new key into the database and
   invalidates the old one.
4. **Billing stub** – Billing integration variables (`STRIPE_PUBLISHABLE_KEY`,
   etc.) were added to `.env.example`.  A decision on using Stripe EU versus
   a self‑hosted invoicing system will be made closer to launch.
5. **Admin panel placeholder** – A settings page stub displays API keys and
   includes buttons for key rotation.  Member invitations and audit logs are
   mentioned but not implemented.  Rate limiting and logging will be
   configured via Traefik middleware in Week 6.

## Consequences

The database schema now supports multi‑tenancy and API key management.  Row
Level Security ensures tenants cannot access each other’s data as long as
JWTs carry the correct `org_id` claim.  The Studio UI sets expectations for
key rotation and member management, which will be backed by real endpoints
and UI polish later.  Billing remains a stub until a provider is chosen.