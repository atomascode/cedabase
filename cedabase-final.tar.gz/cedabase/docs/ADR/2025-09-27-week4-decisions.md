# Week 4 – First Production Deploy (Compose on Hetzner)

Date: 2025‑09‑27

## Context

After laying down the infrastructure in Week 3, we moved on to deploying the
Cedabase stack to Hetzner.  The objectives were to create a production
Docker Compose manifest, integrate Traefik for TLS termination and routing,
introduce basic observability and ensure backups/restores are in place.  The
local development stack from Week 2 provided the starting point.  We needed
to tune it for production by adding health checks, resource limits and
SOPS‑managed secrets.

Supabase docs emphasise that services like PostgREST require strong JWT
secrets and minimal schema exposure【555061165238131†L146-L157】, while the
Realtime server should have telemetry disabled in production【524236409301486†L79-L154】.  We carried
these considerations forward.

## Decision

1. **Separate production compose file** – We introduced `docker-compose.prod.yml`
   that mirrors the local stack but with production‑grade settings: health
   checks for every service, no direct port exposure, and optional resource
   tuning.  The file references encrypted environment variables (to be
   supplied via SOPS in CI) and uses labels for Traefik routing.
2. **Traefik DNS challenge** – Instead of using the HTTP/ALPN challenges we
   opted for the Hetzner DNS challenge to obtain Let’s Encrypt certificates.
   This avoids opening port 80 unnecessarily and works reliably in the EU
   regions.
3. **Observability stack** – We bundled Prometheus, Grafana, Loki and Promtail
   into the production compose file.  Prometheus scrapes Traefik and node
   exporters; Grafana provides dashboards; Loki stores logs.  Configuration
   files live under `ops/`.
4. **Backup strategy** – A nightly `pg_dump` and weekly base backup will be
   orchestrated later via cronjobs on the database node.  Scripts for
   backup/restore will be added under `ops/backups` in Week 4.  Automated
   snapshot schedules were already defined in Terraform.
5. **Credentials and secrets** – Additional variables such as
   `STUDIO_USERNAME`/`STUDIO_PASSWORD`, `STORAGE_BACKEND` and S3 settings were
   documented in `.env.example`.  SOPS remains the mechanism for secret
   management.

## Consequences

The production compose file and observability tooling give us confidence that
services will be healthy and diagnosable when deployed.  Using Traefik’s DNS
challenge simplifies TLS automation on Hetzner.  We still need to implement
the backup scripts and validate restores in Week 4.  Once the stack is
running behind the load balancer we will perform smoke tests and a rollback
drill.