# Week 2 – Core Services Fork & Wiring

Date: 2025‑09‑13

## Context

In Week 2 we customised the self‑hosted Supabase services for Cedabase.  The goal
was to align the upstream open‑source components with the Cedabase product
requirements and prepare for integration on Hetzner Cloud.  We focused on
configuring the core services (Auth, REST, Realtime, Storage and DB admin),
introducing a connection pooler and providing a richer `.env.example` for
operators.

Key references included the upstream GoTrue example environment which shows how
variables such as `GOTRUE_JWT_SECRET`, `GOTRUE_JWT_AUD`, `GOTRUE_SITE_URL` and
SMTP credentials are defined【305172891462237†L0-L23】.  PostgREST requires
explicit configuration of the database schema, anonymous role and JWT secret
environment variables【555061165238131†L146-L157】.  Realtime supports flags
like `SECURE_CHANNELS` and `EXPOSE_METRICS` to control WebSocket
authentication and disable telemetry【524236409301486†L79-L154】.

## Decision

1. **Extended environment variables** – We expanded `.env.example` to include
   additional variables for GoTrue (JWT audience and expiration), SMTP settings
   and PostgREST schema/role configuration.  These variables are commented
   extensively to guide operators and to satisfy GDPR requirements for
   transparency.
2. **Auth service tuning** – The `docker‑compose.yml` file now passes
   `GOTRUE_JWT_AUD`, `GOTRUE_JWT_EXP`, SMTP settings and custom mailer
   subjects into the GoTrue container.  This ensures tokens are scoped to the
   correct audience and that email invitations and password resets use
   Cedabase‑branded subjects.  Issuer/host parameters remain derived from
   `AUTH_SITE_URL`.
3. **REST API schema whitelist** – PostgREST is configured via
   `PGRST_DB_SCHEMA` to expose only the `public` and `storage` schemas and
   uses a configurable anonymous role (`REST_DB_ANON_ROLE`).  We also tuned
   connection pooling and statement timeouts.
4. **Realtime hardening** – We disabled metrics and telemetry with
   `EXPOSE_METRICS=false` and added `DISABLE_TELEMETRY=true`.  JWT claim
   validators continue to require the `authenticated` role【524236409301486†L79-L154】.
5. **Storage API** – Added a simple `ALLOWED_MIME_TYPES` variable so that
   uploads can be restricted at the API layer.  S3 flags remain unused until
   Hetzner Object Storage is introduced.
6. **DB admin gating** – We added `PG_META_JWT_SECRET` to the postgres‑meta
   container so that administrative endpoints can be protected with the same
   JWT secret used by other services.
7. **Connection pooling** – A minimal Supavisor service was introduced to act
   as a PostgreSQL connection pooler.  It is disabled in Traefik and runs on
   its own port.  Operators can enable it in future weeks by routing
   connections through `pooler` rather than directly to Postgres.

## Consequences

These changes provide a more secure and configurable baseline for Cedabase:

* Operators have clear guidance on required secrets and can configure email
  delivery for production.
* The REST API is constrained to intended schemas and roles, reducing
  accidental exposure of internal tables.
* Realtime and DB admin services no longer leak metrics or telemetry in local
  development.
* A path is laid for connection pooling without immediately exposing the
  service.

Next steps will involve integrating these services into the Studio UI, adding
project provisioning flows and expanding E2E tests.