# Week 1 Assumptions & Decisions

Date: 2025‑09‑06

## Context

The primary goal of Week 1 was to establish a monorepo skeleton for the
Cedabase project and to build a local development stack that brings up
all core services end‑to‑end. Due to the limitations of the sandbox
environment (Docker is not available) we focused on scaffolding
configuration and documentation while deferring actual container
orchestration verification to future weeks.

## Assumptions

* Hetzner Cloud will be used exclusively for production deployments with
  the fsn1 region preferred. No other public clouds will be used for
  compute, networking or storage.
* We assume that `pnpm` is the package manager of choice and that all
  services will be built and tested via pnpm workspaces.
* Supabase open source images (Postgres, GoTrue, PostgREST, Realtime,
  Storage API, Postgres Meta and Studio) provide a solid starting point
  for Cedabase. These images are parameterised via environment
  variables as documented in their respective projects【296172281176761†L354-L365】【555061165238131†L146-L157】.
* Traefik is selected as the reverse proxy for local development. It
  will be configured to obtain TLS certificates via Let’s Encrypt
  using the Hetzner DNS challenge in production.

## Decisions

1. **Monorepo structure** – We adopted a pnpm workspace monorepo with
   top‑level directories for `apps`, `services`, `packages`, `infra`,
   `db`, `ops`, `security` and `docs`. This aligns with the project
   brief and simplifies dependency management.

2. **Language and tooling** – TypeScript was chosen as the primary
   language with strict compiler settings. ESLint and Prettier are
   enforced via husky and lint‑staged hooks to maintain code quality.

3. **Local database** – Instead of using the multi‑tenant
   `supabase/postgres` container, we opted for the official
   `postgres:15` image for local development. This simplifies the setup
   and allows our own migration and seeding scripts. RLS is enabled by
   default on the sample `tasks` table.

4. **Environment variables** – A comprehensive `.env.example` file was
   created and parameterised. Sensitive variables such as
   `POSTGRES_PASSWORD`, `JWT_SECRET`, `ANON_KEY` and `SERVICE_ROLE_KEY`
   are to be encrypted via SOPS with age encryption【261391744748816†L129-L144】.

5. **Reverse proxy** – A minimal Traefik configuration is included in
   `docker-compose.yml` to illustrate how services will be routed under
   a single entrypoint. Each service exposes labels to register routers
   and services with Traefik.

6. **Studio rebrand** – A placeholder Next.js application under
   `apps/studio` serves as the initial Studio UI. It displays a
   welcome message and will be extended in later weeks.

7. **Testing** – Vitest is set up for unit testing. An initial smoke
   test is included as a placeholder for future E2E tests. Due to the
   unavailability of Docker in this environment, we cannot run the
   full stack yet. This will be addressed when running on a
   Docker‑capable host.

## Consequences

* Subsequent weeks will build upon this scaffold. Terraform code in
  `infra/terraform` will provision Hetzner Cloud resources, and
  Ansible playbooks will harden the nodes. Once running on a host
  with Docker, the compose file will spin up the services, enabling
  us to perform the end‑to‑end smoke tests specified in the brief.
* Our decision to use the `postgres:15` image for local development
  means that multi‑tenant features must be added manually later or
  replaced with the Supabase all‑in‑one image as needed.
* The heavy use of environment variables allows easy configuration
  across environments but requires diligent secret management and
  consistent documentation.