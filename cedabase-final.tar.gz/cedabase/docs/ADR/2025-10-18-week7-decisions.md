# Week 7 – Optional k3s & Hardening

Date: 2025‑10‑18

## Context

Running the Cedabase stack in containers has been sufficient thus far.  The
project roadmap included an optional migration to a self‑managed k3s
Kubernetes cluster on Hetzner to enable rolling deployments and better
resource utilisation.  However, Kubernetes introduces significant
operational complexity and additional moving parts (CSI drivers, Ingress
controllers, Helm charts) that may not be justified for an MVP.

## Decision

After evaluating the trade‑offs we decided **not** to move to k3s for the
initial beta launch.  Instead we will continue using Docker Compose on the
Hetzner app nodes.  This choice was driven by:

1. **Simplicity and reliability** – Compose is sufficient for the scale of the
   MVP (two app nodes behind a load balancer).  Adding k3s would require
   cluster bootstrapping, CSI setup and additional monitoring.
2. **Time constraints** – Migrating to k3s would consume at least one week of
   engineering effort and increase the risk of delays in the beta launch.
3. **Future flexibility** – The Terraform modules abstract compute nodes
   behind variables, so adopting k3s later will involve provisioning new
   nodes and applying Kubernetes manifests.  Nothing prevents us from
   migrating post‑launch.

Although we are not deploying k3s, we prepared an initial manifest under
`infra/k8s` to document how the services might look.  It includes a
`Namespace`, `Deployments` for each service, `Services` for stable IPs,
`Ingress` objects with Traefik annotations and a `StorageClass` using
Hetzner’s CSI driver.  This manifest is not applied in Week 7.

## Consequences

Staying on Docker Compose reduces operational overhead and allows the team
to focus on feature completeness and hardening.  Rolling updates and
self‑healing remain manual (via Compose) but acceptable at our scale.  We
retain the option to migrate to k3s later with minimal disruption.