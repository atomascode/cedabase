# Week 6 – Reliability & SLOs

Date: 2025‑10‑11

## Context

The sixth week focused on hardening the platform for production.  We needed
to define Service Level Objectives (SLOs), set up load testing, create alert
rules and perform a security review.  These activities ensure Cedabase can
meet performance and uptime targets while identifying issues proactively.

The Realtime and REST services have configurable connection pooling and
timeouts【524236409301486†L79-L154】【555061165238131†L146-L157】 which we tuned to handle
expected workloads.  We also incorporated k6 for load testing.

## Decision

1. **Defined SLOs** – A comprehensive SLO document (`docs/SLO.md`) specifies
   availability and latency targets for the API gateway, database and Studio.
   The document translates percentages into permissible downtime and
   enumerates performance metrics (REST p95 latency, realtime fan‑out, file
   upload throughput).
2. **Monitoring** – Prometheus alert rules were added under
   `ops/prometheus/alerts.yml` to detect high error rates, slow latency,
   resource exhaustion and stale backups.  Future work will integrate
   Alertmanager for notifications.
3. **Load testing** – A k6 script (`ops/k6/load.js`) exercises the REST API
   with concurrent virtual users, asserting that p95 latency stays below
   250 ms and error rate below 1%.  This script will run in CI and in the
   staging environment to catch regressions.
4. **Security review** – The `SECURITY.md` was expanded to document
   web application controls (cookies, CSRF, CORS, HSTS), rate limiting and
   GDPR considerations.  These serve as the baseline for our threat model.
5. **Data retention** – Policies were established: application logs retained
   for 14 days, audit logs for 90 days and metrics for 30 days.  Backup
   schedules from Week 4 remain in effect.

## Consequences

Defining SLOs and alert rules provides a measurable target for the platform’s
performance and availability.  Load testing helps ensure our configuration
delivers acceptable latency under load.  The security enhancements and
documentation reduce the risk of misconfiguration.  In future weeks we will
wire these alerts into on‑call rotations and refine thresholds based on
real‑world usage.