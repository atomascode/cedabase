# GDPR & Data Protection

Cedabase is built with privacy by design and by default.  This document
summarises our approach to EU General Data Protection Regulation (GDPR)
compliance and outlines the processes for data subject rights (DSR), data
processing agreements (DPA) and retention policies.

## Data Processing Agreement (DPA)

Cedabase acts as a data processor on behalf of its customers (the
controllers).  We provide a standard DPA that details our obligations,
including:

* Processing personal data only on documented instructions from the controller.
* Ensuring confidentiality via appropriate technical and organisational
  measures (encryption at rest and in transit, access controls).
* Assisting the controller in complying with data subject rights.
* Not subcontracting processing without prior authorisation.
* Deleting or returning personal data at the end of the contract.

The DPA template resides in `docs/legal/dpa-template.md` (to be drafted by
legal counsel) and can be signed electronically.

## Records of Processing Activities (RoPA)

Under Article 30 GDPR, controllers and processors must maintain a record of
processing activities.  Cedabase maintains an internal RoPA that enumerates
each category of personal data (user credentials, billing info, activity
logs), the purpose of processing, recipients, data retention periods and
security measures.  Customers can request a copy of this record by
contacting our Data Protection Officer at `<CONTACT_EMAIL>`.

## Data Subject Rights (DSR) Flows

Data subjects have the right to access, rectify, erase and port their data.
Cedabase exposes the following administrative endpoints for controllers to
fulfil these requests:

* `GET /admin/dsr/export?user_id=<uuid>` – Returns a JSON export of all rows
  referencing the given user ID across the public schema.
* `POST /admin/dsr/delete` – Accepts a JSON payload `{ "user_id": "<uuid>" }`
  and deletes all personal data associated with the user.  The request
  requires a service JWT and logs an audit event.

These endpoints are implemented as stored procedures in the database and are
exposed via PostgREST with appropriate role checks.  When a DSR request
occurs, the controller should:

1. Authenticate as a service user using the service key.
2. Call the appropriate endpoint.
3. Provide the resulting export to the data subject or confirm deletion.

## Retention Policies

* User authentication records: retained for as long as the user account
  exists plus one year after deletion for fraud prevention.
* Audit logs: retained for 90 days.
* Application data: retained until the customer deletes the project or their
  subscription ends, at which point data is deleted after a 30‑day grace
  period.

## Contact

For any privacy concerns or requests, contact our Data Protection Officer at
`<CONTACT_EMAIL>`.