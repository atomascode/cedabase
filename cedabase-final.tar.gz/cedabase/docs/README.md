# Cedabase Documentation

This directory contains user and developer documentation for the Cedabase
project. High‑level architecture diagrams, design decisions, API guides
and contributor guidelines will be added here throughout the project.

## Structure

- `README.md`: Overview of the repository and high‑level architecture.
- `ADR/`: Architectural decision records capturing significant
  decisions and their rationale.
- `api/`: API reference and examples.
- `infra/`: Infrastructure documentation and runbooks.
- `security/`: Threat model and data protection agreement templates.