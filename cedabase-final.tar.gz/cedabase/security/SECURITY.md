# Security Policy

Cedabase takes security seriously. All secrets are managed via SOPS and age
encryption and never committed in plain text to the repository. The database
is never exposed publicly and network access is restricted via Hetzner
firewalls. HTTP services use TLS by default with automatic certificate
provisioning via Let’s Encrypt. CSRF, CORS, HSTS and other best practices
will be enabled by default across services in upcoming weeks.

## Web application security

* All session cookies are marked `HttpOnly`, `Secure` and `SameSite=Lax`.
* JWTs expire within one hour and are refreshed via a secure endpoint.
* Cross‑Site Request Forgery (CSRF) tokens are required for every state‑changing
  request to the Studio API.  These tokens are rotated frequently.
* Cross‑Origin Resource Sharing (CORS) is configured to allow only
  whitelisted origins defined in the environment.  Unknown origins receive
  a 403 response.
* HTTP Strict Transport Security (HSTS) headers are sent by Traefik with a
  max‑age of one year and include subdomains.

## Rate limiting

Traefik middlewares enforce per‑API key rate limits.  By default, anonymous
keys are allowed 60 requests per minute while service keys are allowed 600
requests per minute.  Exceeding the limit results in a 429 response.  These
limits can be tuned in the Traefik dynamic configuration.

## Data handling & GDPR

* Personal data is stored only within the EU (fsn1 or nbg1) on Hetzner
  equipment.  No data is transferred outside these regions without
  explicit consent.
* Database snapshots and backups are encrypted at rest before being
  uploaded to the Storage Box.
* Data subject requests (export/delete) will be implemented in Week 8 via
  admin tooling.

If you discover a vulnerability, please report it privately to the project
maintainers. Do not disclose it publicly until a fix has been implemented
and deployed.