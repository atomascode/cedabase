#!/usr/bin/env bash

# Database restore script for Cedabase.
#
# Downloads a previously created backup from the S3 bucket and restores it
# into the running PostgreSQL instance.  Use with caution: this will drop
# existing objects.  The backup filename must be supplied as the first
# argument.

set -euo pipefail

if [ "$#" -lt 1 ]; then
  echo "Usage: $0 <backup-file>"
  exit 1
fi

BACKUP_FILE="$1"
TMP_FILE="/tmp/${BACKUP_FILE}"

echo "[restore] downloading ${BACKUP_FILE} from bucket ${S3_BUCKET}..."
aws --endpoint-url="${S3_COMPAT_ENDPOINT}" s3 cp "s3://${S3_BUCKET}/${BACKUP_FILE}" "${TMP_FILE}"

echo "[restore] dropping and recreating database ${POSTGRES_DB}..."
export PGPASSWORD="$POSTGRES_PASSWORD"
psql -h ${POSTGRES_HOST:-localhost} -U ${POSTGRES_USER} -d postgres -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='${POSTGRES_DB}' AND pid <> pg_backend_pid();"
psql -h ${POSTGRES_HOST:-localhost} -U ${POSTGRES_USER} -d postgres -c "DROP DATABASE IF EXISTS \"${POSTGRES_DB}\";"
psql -h ${POSTGRES_HOST:-localhost} -U ${POSTGRES_USER} -d postgres -c "CREATE DATABASE \"${POSTGRES_DB}\";"

echo "[restore] restoring dump..."
gunzip -c "${TMP_FILE}" | psql -h ${POSTGRES_HOST:-localhost} -U ${POSTGRES_USER} -d ${POSTGRES_DB}

echo "[restore] restore complete."