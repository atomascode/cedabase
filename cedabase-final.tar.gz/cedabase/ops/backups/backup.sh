#!/usr/bin/env bash

# Nightly backup script for Cedabase database.
#
# This script performs a logical backup via pg_dump and uploads the result to
# the Hetzner Storage Box or other S3-compatible endpoint configured via
# environment variables.  It is intended to run on the database node via
# cron.  The backup filename includes the current UTC timestamp.

set -euo pipefail

export PGPASSWORD="$POSTGRES_PASSWORD"

TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
BACKUP_FILE="${POSTGRES_DB}_${TIMESTAMP}.sql.gz"

echo "[backup] creating dump ${BACKUP_FILE}..."
pg_dump -h ${POSTGRES_HOST:-localhost} -U ${POSTGRES_USER} -d ${POSTGRES_DB} \
  | gzip > "/tmp/${BACKUP_FILE}"

# Upload to S3 (requires awscli or s5cmd).  Replace with actual upload command.
if command -v aws > /dev/null; then
  echo "[backup] uploading to S3 bucket ${S3_BUCKET}..."
  aws --endpoint-url="${S3_COMPAT_ENDPOINT}" s3 cp "/tmp/${BACKUP_FILE}" "s3://${S3_BUCKET}/${BACKUP_FILE}"
else
  echo "[backup] WARNING: aws CLI not found; backup remains on local disk."
fi

echo "[backup] done."