# Operations Runbook

This runbook provides step‑by‑step procedures for operating the Cedabase
platform, including startup, shutdown, backups, restores and incident
response.  It is a living document that evolves each week of the project.

## Contents

* [Startup and shutdown](#startup-and-shutdown)
* [Backups and restores](#backups-and-restores)
* [Incident response](#incident-response)
* [Status page](#status-page)

## Startup and shutdown

1. SSH into the app nodes using the Hetzner console or your configured SSH
   keys.
2. Navigate to the deployment directory (e.g. `/srv/cedabase`) where the
   `docker-compose.prod.yml` and `.env` files reside.
3. Run `docker compose pull` to fetch the latest images.
4. Start the stack with `docker compose -f docker-compose.prod.yml up -d`.
5. Verify services are healthy using `docker compose ps` and by checking
   Prometheus targets.

To shut down the stack gracefully:

1. Run `docker compose -f docker-compose.prod.yml down` on each app node.
2. Confirm that the load balancer no longer routes traffic.

## Backups and restores

Nightly logical backups are executed via the `backup.sh` script located in
`ops/backups`.  The script runs `pg_dump`, compresses the output and uploads
it to the configured S3 bucket.  To restore a backup, run `restore.sh` with
the filename of the backup to recover.  Ensure that no writes are occurring
during a restore and that you have captured recent WAL files if using
physical backups.

## Incident response

During an incident the primary objective is to restore service as quickly as
possible while preserving data integrity.  The following steps outline a
generic response procedure:

1. **Triage** – Determine if the incident affects all tenants or a single
   project.  Review alerts from Prometheus for CPU, memory, p95 latency and
   HTTP 5xx rates.
2. **Communicate** – Post an update on the status page (see below) and notify
   the on‑call channel.
3. **Mitigate** – If the issue is confined to one service, restart the
   affected container via `docker compose restart <service>`.  If the
   database is unreachable, fail over to the latest backup if replication
   exists.
4. **Escalate** – If the incident cannot be resolved within 15 minutes,
   notify the engineering lead and prepare a rollback to the previous
   deployment tag.
5. **Post‑incident** – Record the timeline, root cause, impact and action
   items in the incident log.

## Status page

A public status page communicates current platform health to users.  In Week 4
we set up a placeholder using a simple static HTML page served from the
`status` folder.  Later we will integrate it with Prometheus alerts to
automatically reflect outage states.