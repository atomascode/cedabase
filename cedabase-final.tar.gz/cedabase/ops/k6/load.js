import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  vus: 20,
  duration: '1m',
  thresholds: {
    http_req_failed: ['rate<0.01'],
    http_req_duration: ['p(95)<250'],
  },
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:8000/rest';

export default function () {
  // Read list
  const res1 = http.get(`${BASE_URL}/tasks`);
  check(res1, {
    'GET /tasks status is 200': (r) => r.status === 200,
  });

  // Write operation
  const payload = JSON.stringify({ name: `k6 task ${Math.random()}` });
  const headers = { 'Content-Type': 'application/json', apikey: __ENV.SERVICE_KEY };
  const res2 = http.post(`${BASE_URL}/tasks`, payload, { headers });
  check(res2, {
    'POST /tasks status is 201': (r) => r.status === 201,
  });

  sleep(1);
}