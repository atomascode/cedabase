# Cedabase

Cedabase is a self‑hosted, EU/GDPR‑first database platform inspired by
Supabase. It bundles together open source components (PostgreSQL,
GoTrue, PostgREST, Realtime, Storage API, Postgres Meta and Studio)
with opinionated defaults for security, compliance and observability.

This repository is organised as a [monorepo](https://pnpm.io/workspaces)
managed with [pnpm](https://pnpm.io/). Each top‑level folder has a
specific purpose:

| Folder        | Purpose                                                                   |
|--------------|---------------------------------------------------------------------------|
| `apps/`      | Frontend applications (e.g. Studio)                                        |
| `services/`  | Backend service configurations for auth, REST, realtime, storage, etc.     |
| `packages/`  | Shared TypeScript packages (config, types, UI components)                 |
| `infra/`     | Infrastructure as code (Terraform, Ansible, k3s)                          |
| `db/`        | Database migrations and seed scripts                                       |
| `ops/`       | Operational runbooks and incident response guides                         |
| `security/`  | Security policy, threat model and data processing agreements              |
| `docs/`      | Documentation and architecture guides                                      |

## Getting Started

1. **Install dependencies**: ensure you have [Docker](https://docs.docker.com/),
   [pnpm](https://pnpm.io/) and [age](https://github.com/FiloSottile/age)
   installed locally.

2. **Generate keys**: run `bash scripts/generate-keys.sh` to create an age key
   pair and a JWT secret. Update `.env` with the generated values and set your
   database password, anon key and service role key. Encrypt the file with
   SOPS using your age key.

3. **Boot the stack**: execute `docker compose up --build` from the root
   directory. After a few moments, Cedabase Studio should be accessible at
   `http://localhost` (proxied via Traefik). Default credentials for Studio are
   `supabase` / `password`; change these immediately.

4. **Run tests**: use `pnpm test` to execute unit tests across all packages.

This repository adheres to strict TypeScript settings and enforces
code quality via ESLint and Prettier. Please consult `.env.example`
for all required environment variables and ensure that secrets are
never committed unencrypted.