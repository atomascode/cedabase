# REST Service

This directory contains configuration for the PostgREST service. Cedabase
uses [PostgREST](https://postgrest.org) to expose a RESTful API on top of
the PostgreSQL database. In Week 1 the configuration is minimal and
provided via environment variables in `docker-compose.yml`. Future weeks
will introduce rate limiting, schema whitelisting and advanced policies.