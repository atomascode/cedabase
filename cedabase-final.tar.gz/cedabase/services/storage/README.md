# Storage Service

Cedabase leverages the [supabase/storage-api](https://github.com/supabase/storage-api)
for file management. The service exposes an S3‑compatible interface and
integrates tightly with PostgREST for authorization. The default
configuration uses the `file` backend to store objects on the local
filesystem. When deploying to Hetzner, the storage backend will switch to
Hetzner Object Storage via the S3‑compatible interface. All service
configuration lives in `docker-compose.yml` and is parameterised via
environment variables defined in `.env`.