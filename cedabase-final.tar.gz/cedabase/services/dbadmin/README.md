# Postgres Meta (DB Admin)

The [postgres-meta](https://github.com/supabase/postgres-meta) service
provides a REST API for managing PostgreSQL databases (running
migrations, creating users, inspecting schemas). Cedabase exposes this
service internally and proxies it via the reverse proxy. In local
development it is available on `/dbadmin`. Any future administrative
extensions should live here.