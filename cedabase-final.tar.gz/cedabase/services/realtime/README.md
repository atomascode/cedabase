# Realtime Service

Cedabase uses the [supabase/realtime](https://github.com/supabase/realtime)
server to broadcast database changes over WebSocket. Configuration is
supplied via environment variables defined in `docker-compose.yml`. This
directory is reserved for any future customisation, such as JWT claim
validators or additional presence features.