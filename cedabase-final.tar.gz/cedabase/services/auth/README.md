# Auth Service

This directory holds configuration and templates for the GoTrue authentication
service used by Cedabase. The actual service is provided by the
[supabase/gotrue](https://github.com/supabase/gotrue) container image as
configured in `docker-compose.yml`. Any custom configuration (email
templates, tenant configuration, JWT claim mappings, etc.) should be added
here and mounted into the container when needed. For Week 1 the default
configuration is sufficient to enable user sign‑up and sign‑in.