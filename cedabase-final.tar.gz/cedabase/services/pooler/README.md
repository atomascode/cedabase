# Pooler (Supavisor)

This folder will contain configuration for database connection pooling,
implemented via [supavisor](https://github.com/supabase/supavisor). Pooling
enables scaling to many concurrent clients by reusing connections. In
Week 1 no pooler is deployed; the Postgres container accepts connections
directly. Week 2 introduces a minimal pooler configuration.