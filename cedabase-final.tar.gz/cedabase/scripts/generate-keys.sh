#!/usr/bin/env bash
set -euo pipefail

# This script generates an age key pair and a random JWT secret. It writes
# the resulting values into a file whose path can be supplied as the first
# argument (defaults to ./keys.txt). If age is not installed on your system
# you can install it from https://github.com/FiloSottile/age.

KEY_FILE=${1:-keys.txt}

echo "Generating age key pair..."
age-keygen -o "$KEY_FILE"

echo "\n# Generated JWT secret" >> "$KEY_FILE"
openssl rand -hex 32 | tr -d '\n' | sed 's/^/export JWT_SECRET=/' >> "$KEY_FILE"
echo "" >> "$KEY_FILE"

echo "Keys generated and saved to $KEY_FILE. Keep this file secure."