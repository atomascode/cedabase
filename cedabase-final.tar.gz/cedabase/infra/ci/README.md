# Continuous Integration

This directory will contain GitHub Actions workflows for linting, testing
and deploying the Cedabase codebase. A baseline CI pipeline will be
introduced in Week 1 to enforce Prettier and ESLint rules. Subsequent
weeks will add jobs for integration tests, container builds and
Terraform validations.