variable "hcloud_token" {
  description = "API token for Hetzner Cloud."
  type        = string
  sensitive   = true
}

variable "network_cidr" {
  description = "CIDR range for the private network"
  type        = string
  default     = "10.0.0.0/16"
}

variable "subnet_cidr" {
  description = "CIDR range for the subnet within the network"
  type        = string
  default     = "10.0.1.0/24"
}

variable "network_zone" {
  description = "Hetzner network zone (e.g. eu-central)"
  type        = string
  default     = "eu-central"
}

variable "location" {
  description = "Hetzner server location/region"
  type        = string
  default     = "fsn1"
}

variable "app_count" {
  description = "Number of application servers"
  type        = number
  default     = 2
}

variable "app_image" {
  description = "Image ID or name to use for application servers"
  type        = string
  default     = "ubuntu-22.04"
}

variable "app_server_type" {
  description = "Hetzner server type for application nodes"
  type        = string
  default     = "cpx21"
}

variable "db_image" {
  description = "Image ID or name for the database server"
  type        = string
  default     = "ubuntu-22.04"
}

variable "db_server_type" {
  description = "Hetzner server type for the database node"
  type        = string
  default     = "ccx31"
}

variable "db_volume_size" {
  description = "Size of the attached volume in GB for the database"
  type        = number
  default     = 100
}

variable "ssh_keys" {
  description = "List of SSH key names or IDs to add to servers"
  type        = list(string)
  default     = []
}

variable "enable_ssh" {
  description = "Whether to open port 22 in the firewall"
  type        = bool
  default     = false
}

variable "ssh_allowed_cidrs" {
  description = "List of CIDR blocks allowed to SSH into servers when SSH is enabled"
  type        = list(string)
  default     = ["0.0.0.0/0"]
}