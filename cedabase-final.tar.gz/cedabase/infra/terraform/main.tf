terraform {
  required_providers {
    hcloud = {
      source  = "hetznercloud/hcloud"
      version = ">= 1.45.0"
    }
  }
  required_version = ">= 1.3.0"
}

provider "hcloud" {
  token = var.hcloud_token
}

###############################################################################
# Network
###############################################################################

# Create a private network for all Cedabase resources.  The CIDR block is
# configurable via `var.network_cidr`.  Hetzner uses /24 networks for
# simplicity; adjust as needed.
resource "hcloud_network" "cedabase" {
  name     = "cedabase-network"
  ip_range = var.network_cidr
}

resource "hcloud_network_subnet" "cedabase_subnet" {
  network_id   = hcloud_network.cedabase.id
  type         = "cloud"
  network_zone = var.network_zone
  ip_range     = var.subnet_cidr
}

###############################################################################
# Firewalls
###############################################################################

resource "hcloud_firewall" "cedabase_public" {
  name = "cedabase-public"

  rule {
    direction = "in"
    protocol  = "tcp"
    port      = "80"
    source_ips = ["0.0.0.0/0", "::/0"]
  }

  rule {
    direction = "in"
    protocol  = "tcp"
    port      = "443"
    source_ips = ["0.0.0.0/0", "::/0"]
  }

  dynamic "rule" {
    for_each = var.enable_ssh ? [1] : []
    content {
      direction  = "in"
      protocol   = "tcp"
      port       = "22"
      source_ips = var.ssh_allowed_cidrs
    }
  }
}

###############################################################################
# Servers
###############################################################################

# App nodes (CPX) for running the Cedabase services.  Use count to create
# multiple nodes; they will join the private network and attach the firewall.
resource "hcloud_server" "app" {
  count  = var.app_count
  name   = "cedabase-app-${count.index + 1}"
  image  = var.app_image
  server_type = var.app_server_type
  location    = var.location
  ssh_keys    = var.ssh_keys
  user_data   = file("${path.module}/cloud-init-app.yaml")
  networks = [hcloud_network.cedabase.id]
  firewall_ids = [hcloud_firewall.cedabase_public.id]
}

# Database node (CCX) with attached volume for persistent storage.
resource "hcloud_volume" "db_volume" {
  name = "cedabase-db-volume"
  size = var.db_volume_size
  server_id = hcloud_server.db.id
}

resource "hcloud_server" "db" {
  name   = "cedabase-db"
  image  = var.db_image
  server_type = var.db_server_type
  location    = var.location
  ssh_keys    = var.ssh_keys
  user_data   = file("${path.module}/cloud-init-db.yaml")
  networks = [hcloud_network.cedabase.id]
  firewall_ids = [hcloud_firewall.cedabase_public.id]
  volume_ids = [hcloud_volume.db_volume.id]
}

###############################################################################
# Load Balancer
###############################################################################

# A load balancer fronts the application nodes and offers a single public IP.
resource "hcloud_load_balancer" "lb" {
  name    = "cedabase-lb"
  load_balancer_type = "lb11"
  location = var.location
  network_id = hcloud_network.cedabase.id
}

resource "hcloud_load_balancer_target" "app_targets" {
  for_each = hcloud_server.app
  load_balancer_id = hcloud_load_balancer.lb.id
  server_id        = each.value.id
}

resource "hcloud_load_balancer_service" "http" {
  load_balancer_id = hcloud_load_balancer.lb.id
  protocol = "tcp"
  listen_port = 80
  destination_port = 80
}

resource "hcloud_load_balancer_service" "https" {
  load_balancer_id = hcloud_load_balancer.lb.id
  protocol = "tcp"
  listen_port = 443
  destination_port = 443
}

###############################################################################
# Outputs
###############################################################################

output "lb_ipv4" {
  description = "Public IPv4 address of the load balancer"
  value       = hcloud_load_balancer.lb.ipv4
}

output "db_private_ip" {
  description = "Private IP of the database server"
  value       = hcloud_server.db.network[0].ip
}