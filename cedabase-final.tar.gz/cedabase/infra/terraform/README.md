# Terraform Infrastructure

This directory will hold Terraform code to provision Cedabase on Hetzner
Cloud. Week 3 focuses on defining the VPC, subnets, firewalls, compute
instances, load balancer and storage boxes. The Terraform code will be
organised into modules for network, compute, security, DNS and storage.