# Ansible Playbooks

Ansible will be used to perform post‑provisioning tasks on Hetzner nodes.
Examples include installing Docker, hardening SSH, configuring Traefik/Caddy
and deploying k3s. These playbooks will be authored in Week 3/7 when the
infrastructure layer is implemented.