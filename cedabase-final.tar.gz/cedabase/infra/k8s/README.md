# Kubernetes (k3s) Manifests

If we elect to deploy Cedabase on k3s, this directory will contain the
manifests and Helm charts used to run the services on a self‑managed
cluster on Hetzner Cloud. This work is optional and planned for Week 7.