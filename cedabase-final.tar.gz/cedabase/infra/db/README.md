# Database Migrations and Seeds

This directory houses SQL migrations and seed data for the core
PostgreSQL database. Migration files live under `db/migrations/` and
follow a numeric prefix ordering, whereas seed files live under
`db/seed/`. A migration tool (such as
[dbmate](https://github.com/dbmate/dbmate) or `supabase/migrator`) can
be integrated to apply these files in CI/CD pipelines.