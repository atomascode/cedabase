-- Create organisations and projects for multi-tenancy.

CREATE TABLE IF NOT EXISTS public.organisations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES public.organisations(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- API keys table.  Keys are associated with a project and have a role and
-- expiration.  Service keys bypass RLS; anon keys enforce RLS.
CREATE TABLE IF NOT EXISTS public.api_keys (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  key TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('anon', 'service')),
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  rotated_at TIMESTAMPTZ
);

-- Enable Row Level Security
ALTER TABLE public.organisations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

-- RLS policies.  Only allow members of an organisation to view their org and
-- projects.  In this simplified example we assume a JWT claim "org_id" is
-- provided.  Service keys bypass RLS.
CREATE POLICY organisations_select ON public.organisations FOR SELECT USING (
  current_setting('request.jwt.claims', true)::json ->> 'role' = 'service' OR
  current_setting('request.jwt.claims', true)::json ->> 'org_id' = id::text
);

CREATE POLICY projects_select ON public.projects FOR SELECT USING (
  current_setting('request.jwt.claims', true)::json ->> 'role' = 'service' OR
  current_setting('request.jwt.claims', true)::json ->> 'org_id' = org_id::text
);