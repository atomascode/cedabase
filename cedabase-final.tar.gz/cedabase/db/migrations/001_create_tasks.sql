-- 001_create_tasks.sql
--
-- This migration creates a simple "tasks" table in the public schema with
-- row level security (RLS) enabled by default. Each task belongs to a user
-- identified by their UUID. This serves as an example for creating tables
-- with sensible defaults for a multi‑tenant backend.

create extension if not exists pgcrypto;

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  name text not null,
  is_complete boolean not null default false,
  inserted_at timestamp with time zone not null default now()
);

-- Enable row level security so that policies can restrict access per user.
alter table public.tasks enable row level security;

-- Policy to allow owners to read and write their own tasks.
create policy if not exists "Task owners can select and modify their tasks"
  on public.tasks
  for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);