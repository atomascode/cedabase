-- Seed initial organisation and project for development purposes.

INSERT INTO public.organisations (name)
VALUES ('Dev Org')
ON CONFLICT DO NOTHING;

INSERT INTO public.projects (org_id, name, description)
SELECT id, 'Dev Project', 'Initial development project'
FROM public.organisations WHERE name = 'Dev Org'
ON CONFLICT DO NOTHING;

-- Generate API keys for anon and service roles.  In production these will be
-- generated via the key rotation endpoints.
INSERT INTO public.api_keys (project_id, key, role)
SELECT p.id,
       encode(gen_random_bytes(16), 'hex'),
       'anon'
FROM public.projects p
WHERE p.name = 'Dev Project'
ON CONFLICT DO NOTHING;

INSERT INTO public.api_keys (project_id, key, role)
SELECT p.id,
       encode(gen_random_bytes(16), 'hex'),
       'service'
FROM public.projects p
WHERE p.name = 'Dev Project'
ON CONFLICT DO NOTHING;