-- seed_tasks.sql
--
-- Populates the tasks table with an initial row. In a real deployment this
-- would be replaced with migrations applied via a tool such as pgmigrate or
-- node-postgres. The purpose of this seed is to verify that the REST API
-- and realtime subscriptions function correctly.

insert into public.tasks (user_id, name, is_complete)
values (
  gen_random_uuid(),
  'Hello, Cedabase!',
  false
);