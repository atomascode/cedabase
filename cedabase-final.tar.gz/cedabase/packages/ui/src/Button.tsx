import React from 'react';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
}

/**
 * A simple reusable button component. This will eventually be replaced with
 * a comprehensive design system, but serves as a starting point for the UI
 * package. Use the `className` prop to further style the button via
 * Tailwind CSS or your preferred CSS framework.
 */
export const Button: React.FC<ButtonProps> = ({ children, ...props }) => {
  return (
    <button
      {...props}
      className={
        'px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700 ' +
        (props.className ?? '')
      }
    >
      {children}
    </button>
  );
};