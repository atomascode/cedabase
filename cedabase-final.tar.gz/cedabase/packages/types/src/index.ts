// Shared type definitions for the Cedabase platform.

export interface User {
  id: string;
  email: string;
  createdAt: string;
}

export interface Task {
  id: string;
  userId: string;
  name: string;
  isComplete: boolean;
  insertedAt: string;
}

/**
 * A project represents a tenant within the Cedabase platform.  Projects map to
 * individual Postgres databases and their associated Supabase services.  In
 * later weeks the backend will provision these resources on demand.
 */
export interface Project {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

/** Organisation represents a tenant grouping multiple projects. */
export interface Organisation {
  id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
}

/** API keys correspond to anon or service roles scoped to a project. */
export interface ApiKey {
  id: string;
  projectId: string;
  key: string;
  role: 'anon' | 'service';
  expiresAt?: string;
  createdAt: string;
  rotatedAt?: string;
}