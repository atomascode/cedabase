export interface ServiceConfig {
  authUrl: string;
  restUrl: string;
  realtimeUrl: string;
  storageUrl: string;
  studioUrl: string;
}

// A sample configuration object that can be imported across services and apps.
export const defaultConfig: ServiceConfig = {
  authUrl: process.env.AUTH_SITE_URL ?? 'http://localhost:8000/auth/v1',
  restUrl: process.env.REST_BASE_URL ?? 'http://localhost:8000/rest/v1',
  realtimeUrl: process.env.REALTIME_BASE_URL ?? 'ws://localhost:4000',
  storageUrl: process.env.STORAGE_BASE_URL ?? 'http://localhost:5000/storage/v1',
  studioUrl: process.env.STUDIO_HOST ?? 'http://localhost:3000',
};