import Head from 'next/head';
import React, { useState } from 'react';

/**
 * Settings page for organisation and project configuration.  Users can view
 * their API keys and rotate them.  In Week 5 this is only a stub – the
 * buttons do not call a backend yet.
 */
export default function SettingsPage() {
  const [anonKey, setAnonKey] = useState('sk_anon_placeholder');
  const [serviceKey, setServiceKey] = useState('sk_service_placeholder');

  const rotateAnon = () => {
    // TODO: call API to rotate anon key
    setAnonKey('sk_anon_rotated_' + Math.random().toString(36).substring(2));
  };
  const rotateService = () => {
    // TODO: call API to rotate service key
    setServiceKey('sk_service_rotated_' + Math.random().toString(36).substring(2));
  };

  return (
    <>
      <Head>
        <title>Settings – Cedabase Studio</title>
      </Head>
      <main style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
        <h1 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Project Settings</h1>
        <h2 style={{ fontSize: '1.25rem', marginBottom: '0.5rem' }}>API Keys</h2>
        <div style={{ marginBottom: '1rem' }}>
          <label
            style={{ display: 'block', fontWeight: 'bold', marginBottom: '.25rem' }}
          >
            Anonymous key
          </label>
          <input
            type="text"
            value={anonKey}
            readOnly
            style={{ width: '100%', padding: '.5rem' }}
          />
          <button
            type="button"
            onClick={rotateAnon}
            style={{ marginTop: '.5rem', padding: '.5rem 1rem' }}
          >
            Rotate anon key
          </button>
        </div>
        <div style={{ marginBottom: '1rem' }}>
          <label
            style={{ display: 'block', fontWeight: 'bold', marginBottom: '.25rem' }}
          >
            Service key
          </label>
          <input
            type="text"
            value={serviceKey}
            readOnly
            style={{ width: '100%', padding: '.5rem' }}
          />
          <button
            type="button"
            onClick={rotateService}
            style={{ marginTop: '.5rem', padding: '.5rem 1rem' }}
          >
            Rotate service key
          </button>
        </div>
        <h2 style={{ fontSize: '1.25rem', marginBottom: '.5rem' }}>Members (coming soon)</h2>
        <p>Invite team members to collaborate on this project.</p>
      </main>
    </>
  );
}