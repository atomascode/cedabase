import Head from 'next/head';
import { useState } from 'react';
import { useRouter } from 'next/router';

/**
 * Project creation page.
 *
 * This stub simulates creating a new project by collecting a name and
 * description.  When the form is submitted we simply redirect back to the
 * projects list.  In future weeks this will call a Cedabase API to
 * provision a new Postgres database and configure the core services.
 */
export default function CreateProjectPage() {
  const router = useRouter();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) {
      setError('Project name is required');
      return;
    }
    // Placeholder for API call
    console.log('Creating project', { name, description });
    // Redirect back to projects list
    await router.push('/projects');
  };

  return (
    <>
      <Head>
        <title>Create Project – Cedabase Studio</title>
      </Head>
      <main
        style={{
          maxWidth: '40rem',
          margin: '0 auto',
          padding: '2rem',
          fontFamily: 'sans-serif',
        }}
      >
        <h1 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Create a new project</h1>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '1rem' }}>
            <label htmlFor="name" style={{ display: 'block', marginBottom: '.5rem' }}>
              Project name
            </label>
            <input
              id="name"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              style={{ width: '100%', padding: '.5rem' }}
              required
            />
          </div>
          <div style={{ marginBottom: '1rem' }}>
            <label htmlFor="description" style={{ display: 'block', marginBottom: '.5rem' }}>
              Description (optional)
            </label>
            <textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              style={{ width: '100%', padding: '.5rem', minHeight: '6rem' }}
            />
          </div>
          {error && (
            <p style={{ color: 'red', marginBottom: '1rem' }}>{error}</p>
          )}
          <button
            type="submit"
            style={{
              padding: '.75rem 1.5rem',
              backgroundColor: '#0070f3',
              color: '#fff',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer',
            }}
          >
            Create
          </button>
        </form>
      </main>
    </>
  );
}