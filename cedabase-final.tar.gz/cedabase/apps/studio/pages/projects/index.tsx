import Link from 'next/link';
import Head from 'next/head';
import React from 'react';

/**
 * Projects list page.
 *
 * In Week 2 we don't yet persist projects to the backend.  This page simply
 * serves as a placeholder for a future list of the user's projects.  It
 * encourages the user to create their first project.
 */
export default function ProjectsPage() {
  return (
    <>
      <Head>
        <title>Projects – Cedabase Studio</title>
      </Head>
      <main
        style={{
          padding: '2rem',
          fontFamily: 'sans-serif',
        }}
      >
        <h1 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>Your Projects</h1>
        <p>
          You don't have any projects yet.{' '}
          <Link href="/projects/create" style={{ color: '#0066ff' }}>
            Create your first project
          </Link>
          .
        </p>
      </main>
    </>
  );
}