import Head from 'next/head';
import React from 'react';

export default function Home() {
  return (
    <>
      <Head>
        <title>Cedabase Studio</title>
        <meta name="description" content="Self-hosted Cedabase Studio" />
      </Head>
      <main
        style={{
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'center',
          height: '100vh',
          fontFamily: 'sans-serif',
          textAlign: 'center',
          padding: '0 1rem',
        }}
      >
        <h1 style={{ fontSize: '2rem', marginBottom: '1rem' }}>
          Welcome to Cedabase Studio
        </h1>
        <p style={{ maxWidth: '30rem', marginBottom: '2rem' }}>
          Cedabase Studio is your dashboard for managing projects, tables,
          authentication and realtime features. Start by creating your first
          project.
        </p>
        <a
          href="/projects"
          style={{
            padding: '0.75rem 1.5rem',
            backgroundColor: '#0070f3',
            color: '#fff',
            borderRadius: '4px',
            textDecoration: 'none',
          }}
        >
          Go to Projects
        </a>
      </main>
    </>
  );
}