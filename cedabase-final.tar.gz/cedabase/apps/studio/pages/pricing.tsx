import Head from 'next/head';
import React from 'react';

/**
 * Pricing page outlines plans and limits for the beta.  During Week 8 this
 * page provides indicative pricing only and is subject to change prior to GA.
 */
export default function PricingPage() {
  return (
    <>
      <Head>
        <title>Pricing – Cedabase</title>
      </Head>
      <main style={{ maxWidth: '40rem', margin: '0 auto', padding: '2rem', fontFamily: 'sans-serif' }}>
        <h1 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Pricing</h1>
        <p>Our beta is free for early adopters.  When we launch GA, we plan to offer the following tiers:</p>
        <ul>
          <li><strong>Hobby</strong> – €0/mo – 1 project, 2 GB database, 2 GB storage, 1 GB transfer.</li>
          <li><strong>Startup</strong> – €29/mo – 5 projects, 20 GB database, 50 GB storage, 20 GB transfer.</li>
          <li><strong>Business</strong> – €99/mo – 20 projects, 100 GB database, 200 GB storage, 100 GB transfer.</li>
        </ul>
        <p>Additional usage is billed at €0.10 per GB of storage and transfer.  Pricing is subject to VAT.
        </p>
        <p>Contact us at <a href="mailto:<CONTACT_EMAIL>"><CONTACT_EMAIL></a> for custom enterprise plans.</p>
      </main>
    </>
  );
}