import { describe, it, expect } from 'vitest';

// A placeholder smoke test for Week 1. Later weeks will replace this with
// Playwright tests that exercise the full stack (signup, insert row via REST,
// realtime subscription and file upload via storage API).

describe('Week 2 smoke tests', () => {
  it('sanity: true is still true', () => {
    expect(true).toBe(true);
  });

  it('Project type has required fields', () => {
    // This test constructs a Project object and ensures TypeScript allows
    // required fields and optional description.  At runtime this is a simple
    // object check; the primary benefit is catching type drift during CI.
    const project = {
      id: 'proj_123',
      name: 'Test project',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    expect(project.name).toBe('Test project');
    expect(project.id).toMatch(/^proj_/);
  });
});